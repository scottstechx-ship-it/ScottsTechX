/**
 * Shared UI helpers: layout (sidebar + topbar + bell + user menu), toasts,
 * modals, formatting, notification polling and the mobile bottom nav.
 */
(function () {
  const API = window.API;
  const BASE = API.base;

  /** Inline SVG icon (never emoji). Falls back to the label text. */
  function icon(name, opts = {}) {
    if (window.Icons) return window.Icons.svg(name, opts);
    return '';
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function el(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  }

  /** Parse HTML into a DocumentFragment (keeps ALL top-level nodes). */
  function frag(html) {
    const t = document.createElement('template');
    t.innerHTML = html;
    return t.content;
  }

  function initials(name) {
    return (name || '?').split(/\s+/).map((w) => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
  }

  /**
   * Avatar URL for a user, or null when none is set.
   * The request is authenticated by the session cookie the browser attaches
   * automatically, so no token has to be embedded in the URL (URLs end up in
   * logs, referrers and the browser history).
   */
  function avatarUrl(user) {
    if (user && user.profilePicture) {
      return `${API.base}/api/users/${user.id}/avatar?ts=${Date.now()}`;
    }
    return null;
  }

  /** Public URL of the school logo (404 when not uploaded yet). */
  function logoUrl() {
    return `${API.base}/api/settings/logo`;
  }

  /**
   * Fill a logo container with the school logo image, falling back to the
   * graduation mark when no logo is set or the file cannot load.
   */
  function applySchoolLogo(container) {
    if (!container) return;
    const img = new Image();
    img.onload = () => {
      container.innerHTML = '';
      container.classList.add('has-logo');
      container.appendChild(img);
    };
    img.onerror = () => {
      // fall back to the website logo, then the graduation mark
      const site = new Image();
      site.onload = () => {
        container.innerHTML = '';
        container.classList.add('has-logo');
        site.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;border-radius:9px';
        container.appendChild(site);
      };
      site.onerror = () => { container.innerHTML = icon('admissions', { size: 20 }); };
      site.src = '/assets/images/logo.jpeg';
      site.alt = 'School logo';
    };
    img.src = logoUrl() + '?t=' + Date.now();
    img.alt = 'School logo';
    img.style.cssText = 'width:100%;height:100%;object-fit:contain;display:block';
  }

  /** Avatar element: <img> when the user has a photo, initials otherwise. */
  function avatar(user, size = 34, cls = 'avatar') {
    const url = avatarUrl(user);
    const style = size ? `style="width:${size}px;height:${size}px"` : '';
    if (url) {
      return `<div class="${cls}" ${style} style="overflow:hidden;${size ? `width:${size}px;height:${size}px;` : ''}"><img src="${url}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%"></div>`;
    }
    return `<div class="${cls}" ${style}>${esc(initials(user ? user.fullName : '?'))}</div>`;
  }

  function timeAgo(iso) {
    if (!iso) return '';
    const d = new Date(iso.replace(' ', 'T') + (iso.includes('T') ? '' : 'Z'));
    const secs = Math.floor((Date.now() - d.getTime()) / 1000);
    if (isNaN(secs) || secs < 0) return '';
    if (secs < 60) return 'just now';
    if (secs < 3600) return Math.floor(secs / 60) + 'm ago';
    if (secs < 86400) return Math.floor(secs / 3600) + 'h ago';
    if (secs < 604800) return Math.floor(secs / 86400) + 'd ago';
    return d.toLocaleDateString();
  }

  function fmtTime(iso) {
    if (!iso) return '';
    const d = new Date(iso.replace(' ', 'T') + (iso.includes('T') ? '' : 'Z'));
    if (isNaN(d.getTime())) return '';
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function fmtDate(iso) {
    if (!iso) return '';
    const d = new Date(iso.replace(' ', 'T') + (iso.includes('T') ? '' : 'Z'));
    if (isNaN(d.getTime())) return '';
    return d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
  }

  function fmtSize(bytes) {
    if (!bytes && bytes !== 0) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  /**
   * Open a server-rendered printable document (report card, statement,
   * receipt) in a new tab. Uses a real link click so popup blockers leave it
   * alone, and the session cookie travels with the request.
   */
  function openPrintable(path) {
    const a = document.createElement('a');
    a.href = path;
    a.target = '_blank';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  /** Debounce a function (used for search inputs). */
  function debounce(fn, ms = 300) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  }

  /** Simple currency formatting (UGX). */
  function money(n) {
    const v = Number(n || 0);
    return v.toLocaleString('en-US', { maximumFractionDigits: 0 });
  }

  /** Lightweight SVG bar chart — no external chart library needed. */
  function barChart(container, data, { color = 'var(--primary)', height = 140, format = (v) => v } = {}) {
    container.innerHTML = '';
    if (!data || !data.length) {
      container.innerHTML = '<div class="doc-meta">No data yet.</div>';
      return;
    }
    const max = Math.max(...data.map((d) => d.value), 1);
    const pad = 4;
    const labelH = 22;
    const chartH = height - labelH;
    const totalW = container.clientWidth || 480;
    const bw = Math.max(8, Math.min(46, (totalW - pad * data.length) / data.length));
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', String(height));
    svg.setAttribute('viewBox', `0 0 ${Math.max(totalW, data.length * (bw + pad))} ${height}`);
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Bar chart');
    data.forEach((d, i) => {
      const h = Math.max(2, (d.value / max) * chartH);
      const x = i * (bw + pad) + pad / 2;
      const y = chartH - h;
      const rect = document.createElementNS(svgNS, 'rect');
      rect.setAttribute('x', String(x));
      rect.setAttribute('y', String(y));
      rect.setAttribute('width', String(bw));
      rect.setAttribute('height', String(h));
      rect.setAttribute('rx', '4');
      rect.setAttribute('fill', color);
      rect.setAttribute('data-value', String(d.value));
      rect.setAttribute('data-label', esc(d.label || ''));
      const title = document.createElementNS(svgNS, 'title');
      title.textContent = `${d.label}: ${format(d.value)}`;
      rect.appendChild(title);
      svg.appendChild(rect);
      const tx = document.createElementNS(svgNS, 'text');
      tx.setAttribute('x', String(x + bw / 2));
      tx.setAttribute('y', String(height - 6));
      tx.setAttribute('text-anchor', 'middle');
      tx.setAttribute('font-size', '9');
      tx.setAttribute('fill', 'var(--muted)');
      tx.textContent = String(d.label).length > 8 ? String(d.label).slice(0, 7) + '…' : String(d.label);
      svg.appendChild(tx);
    });
    container.appendChild(svg);
  }

  // ---------------- toasts ----------------
  function toast(msg, type = 'info') {
    let box = document.getElementById('toasts');
    if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
    const iconName = { success: 'check', error: 'warning', warning: 'warning', info: 'info' }[type];
    const t = el(`<div class="toast ${type}"><span class="t-ic">${icon(iconName, { size: 16 })}</span><span>${esc(msg)}</span></div>`);
    box.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 320); }, 3800);
  }

  // ---------------- modal ----------------
  /** Modals are stacked (a dialog can open over another): Escape closes the top one. */
  const modalStack = [];

  /**
   * Scroll lock, counted.
   *
   * Several things lock the page at once (a modal, the phone sidebar, a modal
   * opened ON the sidebar). A boolean-style lock meant whichever closed last
   * handed scrolling back — so closing the sidebar released the page behind an
   * open dialog, and closing a dialog on top of the sidebar left the page
   * frozen. Counting the locks makes the last owner release it, and the
   * original inline value is restored exactly.
   */
  let scrollLocks = 0;
  function lockScroll() {
    scrollLocks++;
    if (scrollLocks === 1) {
      document.body.dataset.prevOverflow = document.body.style.overflow || '';
      document.body.style.overflow = 'hidden';
    }
  }
  function unlockScroll() {
    if (scrollLocks === 0) return;
    scrollLocks--;
    if (scrollLocks === 0) {
      document.body.style.overflow = document.body.dataset.prevOverflow || '';
      delete document.body.dataset.prevOverflow;
    }
  }
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !modalStack.length) return;
    // only the topmost dialog reacts, so Escape never closes two at once
    modalStack[modalStack.length - 1].close();
  });

  /**
   * @param {string} title     plain text — it is escaped, so never pass markup
   * @param {string} [titleIcon] optional icon NAME drawn before the title
   *                           (use this instead of putting an <svg> in title:
   *                           markup in an escaped field prints as text)
   */
  function openModal({ title, titleIcon, body, foot, wide = false, onClose }) {
    // A dialog that is fading out is already gone as far as the user is
    // concerned, but its DOM (and its ids) can still be in the page for another
    // ~180ms. Two modals with the same field ids in the document at once is
    // invalid HTML and makes `#id` lookups unpredictable, so clear the corpse
    // before the next dialog is built.
    document.querySelectorAll('.modal-backdrop:not(.open)').forEach((b) => b.remove());

    const backdrop = el(`<div class="modal-backdrop" role="dialog" aria-modal="true">
      <div class="modal ${wide ? 'wide' : ''}" tabindex="-1">
        <div class="modal-head"><h3>${titleIcon ? icon(titleIcon, { size: 18 }) : ''}${esc(title)}</h3><button class="close-x" data-close aria-label="Close">${icon('close', { size: 16 })}</button></div>
        <div class="modal-body"></div>
        ${foot ? '<div class="modal-foot"></div>' : ''}
      </div></div>`);
    const head = backdrop.querySelector('.modal-head h3');
    if (head) backdrop.querySelector('.modal').setAttribute('aria-label', head.textContent);
    backdrop.querySelector('.modal-body').appendChild(typeof body === 'string' ? frag(body) : body);
    if (foot) backdrop.querySelector('.modal-foot').appendChild(typeof foot === 'string' ? frag(foot) : foot);
    document.body.appendChild(backdrop);

    const control = { backdrop, close: () => close() };
    let closed = false;
    function close() {
      if (closed) return;
      closed = true;
      const at = modalStack.indexOf(control);
      if (at > -1) modalStack.splice(at, 1);
      backdrop.classList.remove('open');
      setTimeout(() => backdrop.remove(), 180);
      unlockScroll();
      if (onClose) onClose();
    }
    control.close = close;

    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop || e.target.closest('[data-close]')) close();
    });

    modalStack.push(control);
    lockScroll();
    requestAnimationFrame(() => {
      backdrop.classList.add('open');
      // move focus into the dialog so keyboards and screen readers land in it
      const focusable = backdrop.querySelector('input, select, textarea, button:not(.close-x), [href]');
      if (focusable && typeof focusable.focus === 'function') focusable.focus();
      else backdrop.querySelector('.modal').focus();
    });
    return control;
  }

  function confirmDialog(message, { title = 'Are you sure?', danger = true, confirmText = 'Confirm' } = {}) {
    return new Promise((resolve) => {
      // A promise resolves only once — settle guard so closing the dialog after
      // pressing Confirm cannot override the answer with `false`.
      let settled = false;
      const done = (val) => { if (!settled) { settled = true; resolve(val); } };
      const m = openModal({
        title,
        body: `<p>${esc(message)}</p>`,
        foot: `<button class="btn secondary" data-no>Cancel</button>
               <button class="btn ${danger ? 'danger' : ''}" data-yes>${esc(confirmText)}</button>`,
        onClose: () => done(false),
      });
      m.backdrop.querySelector('[data-no]').onclick = () => m.close();
      m.backdrop.querySelector('[data-yes]').onclick = () => { done(true); m.close(); };
    });
  }

  // ---------------- notification polling ----------------
  let unreadCallbacks = [];
  function onUnreadChange(cb) { unreadCallbacks.push(cb); }
  function notifyUnread() { unreadCallbacks.forEach((cb) => cb && cb()); }

  async function refreshUnreadCounts() {
    try {
      const [msgs, notif] = await Promise.all([
        API.get('/api/messages/unread-count'),
        API.get('/api/notifications/unread-count'),
      ]);
      window.__unread = { messages: msgs.unread || 0, notifications: notif.unread || 0 };
      notifyUnread();
    } catch { /* ignore */ }
  }

  async function loadNotifications() {
    try {
      const data = await API.get('/api/notifications?limit=25');
      return data.notifications || [];
    } catch { return []; }
  }

  // ---------------- global search ----------------
  /**
   * One search box for the whole platform, added to the topbar of every
   * dashboard by initLayout. Results come from /api/search, which already
   * applies each role's access rules, so the box can never reveal a record the
   * user is not allowed to open.
   */
  function initGlobalSearch({ topbar, onNav }) {
    const box = topbar.querySelector('#global-search');
    const input = topbar.querySelector('#gs-input');
    const drop = topbar.querySelector('#gs-drop');
    const clearBtn = topbar.querySelector('#gs-clear');
    const mobileBtn = topbar.querySelector('#gs-mobile-btn');
    if (!box || !input || !drop) return;

    let reqId = 0;
    let items = [];      // flattened, in display order
    let active = -1;

    const closeDrop = () => {
      drop.hidden = true;
      drop.innerHTML = '';
      active = -1;
      box.classList.remove('open');
    };

    /** Flatten the grouped payload so keyboard navigation is a single list. */
    function render(payload) {
      const q = payload.query || '';
      if (!payload.groups || !payload.groups.length) {
        drop.innerHTML = `<div class="gs-empty">${
          payload.hint ? esc(payload.hint) : `No matches for “${esc(q)}”.`
        }</div>`;
        drop.hidden = false;
        box.classList.add('open');
        items = [];
        active = -1;
        return;
      }
      items = [];
      const parts = payload.groups.map((g) => {
        const rows = g.items.map((it) => {
          const idx = items.push(it) - 1;
          const badge = it.badge ? `<span class="badge ${badgeClass(it.badge)}">${esc(it.badge)}</span>` : '';
          return `<button class="gs-item" type="button" role="option" data-i="${idx}">
            <span class="gs-item-ic">${icon(navIcon(it), { size: 15 })}</span>
            <span class="gs-item-main"><span class="gs-item-title">${esc(it.title)}</span>
              <span class="gs-item-sub">${esc(it.subtitle || '')}</span></span>
            ${badge}<span class="gs-item-go" aria-hidden="true">${icon('arrowRight', { size: 14 })}</span>
          </button>`;
        }).join('');
        return `<div class="gs-group"><div class="gs-group-h">${esc(g.label)} <span class="gs-count">${g.count}</span></div>${rows}</div>`;
      }).join('');
      drop.innerHTML = parts + `<div class="gs-foot">${payload.total} result${payload.total === 1 ? '' : 's'} — Enter opens the first match, Esc closes</div>`;
      drop.hidden = false;
      box.classList.add('open');
      // if the input was cleared while the request was in flight, stay shut
      if (!input.value.trim()) closeDrop();
    }

    function badgeClass(b) {
      const v = String(b).toLowerCase();
      if (['active', 'published', 'paid'].includes(v)) return 'green';
      if (['important', 'suspended', 'overdue'].includes(v)) return 'red';
      if (['scheduled', 'pending', 'draft'].includes(v)) return 'amber';
      return 'gray';
    }

    /** Icon name used as the result-type avatar. */
    function navIcon(it) {
      const map = {
        student: 'students', user: 'users', class: 'classes', subject: 'subjects',
        document: 'document', announcement: 'announcements', message: 'messages',
        assignment: 'assignments', exam: 'exams', payment: 'fees',
      };
      return map[it.type] || 'search';
    }

    function search() {
      const q = input.value.trim();
      clearBtn.hidden = !q;
      if (q.length < 2) {
        closeDrop();
        return;
      }
      const mine = ++reqId;
      drop.innerHTML = `<div class="gs-loading"><span class="gs-spin" aria-hidden="true"></span> Searching…</div>`;
      drop.hidden = false;
      box.classList.add('open');
      API.get(`/api/search?q=${encodeURIComponent(q)}`)
        .then((data) => { if (mine === reqId) render(data); })
        .catch((e) => {
          if (mine !== reqId) return;
          drop.innerHTML = `<div class="gs-empty">${esc(e.message || 'Search failed.')}</div>`;
          drop.hidden = false;
        });
    }

    function setActive(i) {
      const all = [...drop.querySelectorAll('.gs-item')];
      if (!all.length) return;
      active = (i + all.length) % all.length;
      all.forEach((b, n) => b.classList.toggle('active', n === active));
      const cur = all[active];
      if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: 'nearest' });
    }

    const doSearch = debounce(search, 250);

    input.addEventListener('input', () => doSearch());
    input.addEventListener('focus', () => { if (input.value.trim().length >= 2 && drop.innerHTML) drop.hidden = false; });
    clearBtn.addEventListener('click', () => { input.value = ''; clearBtn.hidden = true; closeDrop(); input.focus(); });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); setActive(active + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
      else if (e.key === 'Enter') {
        e.preventDefault();
        const target = items[active] || items[0];
        if (target) openResult(target);
      } else if (e.key === 'Escape') {
        if (drop.hidden) input.value = '';
        closeDrop();
      }
    });

    drop.addEventListener('click', (e) => {
      const btn = e.target.closest('.gs-item');
      if (!btn) return;
      const it = items[Number(btn.dataset.i)];
      if (it) openResult(it);
    });

    // click anywhere else closes the panel
    document.addEventListener('click', (e) => { if (!box.contains(e.target) && e.target !== mobileBtn) closeDrop(); });

    // a small phone hides the input behind a magnifier button
    if (mobileBtn) {
      mobileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        box.classList.toggle('mobile-open');
        if (box.classList.contains('mobile-open')) input.focus();
        else closeDrop();
      });
    }

    // Ctrl/⌘+K or "/" jumps into search from anywhere
    document.addEventListener('keydown', (e) => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '');
      if ((e.key === 'k' && (e.ctrlKey || e.metaKey)) || (e.key === '/' && !typing)) {
        e.preventDefault();
        box.classList.add('mobile-open');
        input.focus();
        input.select();
      }
    });

    /**
     * Show the record. Every result carries the fields the API already
     * returned, so the detail card opens instantly; "Go to section" then hands
     * control back to the dashboard.
     */
    function openResult(it) {
      closeDrop();
      const rows = (it.meta || []).map(([label, value]) => `
        <div class="gs-meta-row"><span>${esc(label)}</span><strong>${esc(String(value == null || value === '' ? '—' : value))}</strong></div>`).join('');
      const canOpenFile = !!it.href;
      const m = openModal({
        title: it.title,
        titleIcon: navIcon(it),
        wide: true,
        body: `<div class="gs-detail">
            <div class="gs-detail-sub">${esc(it.subtitle || '')}</div>
            <div class="gs-meta">${rows}</div>
          </div>`,
        foot: `<button class="btn secondary" data-cancel>Close</button>
               ${canOpenFile ? `<button class="btn secondary" data-file>${it.type === 'payment' ? 'Print receipt' : 'Open file'}</button>` : ''}
               <button class="btn" data-go>Go to ${esc(sectionLabel(it.nav))}</button>`,
      });
      m.backdrop.querySelector('[data-cancel]').onclick = () => m.close();
      m.backdrop.querySelector('[data-go]').onclick = () => {
        m.close();
        if (typeof onNav === 'function') onNav(it.nav);
      };
      const fileBtn = m.backdrop.querySelector('[data-file]');
      if (fileBtn) fileBtn.onclick = () => {
        // opens in a new tab with the session cookie attached
        openPrintable(it.href);
        m.close();
      };
    }

    function sectionLabel(key) {
      const b = sidebarNavLabel(key);
      return b || 'section';
    }
    function sidebarNavLabel(key) {
      const btn = document.querySelector(`.nav-item[data-nav="${key}"]`);
      if (!btn) return '';
      const clone = btn.cloneNode(true);
      clone.querySelectorAll('.badge').forEach((x) => x.remove());
      return clone.textContent.trim();
    }
  }

  // ---------------- layout ----------------
  const ROLE_PATHS = { super_admin: 'super-admin', admin: 'admin', teacher: 'teacher', student: 'student', parent: 'parent' };

  /**
   * Build the app shell.
   * nav: [{key, label, icon, section}]
   * bottomNav: [{key, label, icon}]
   */
  async function initLayout({ nav, bottomNav = null, title, onNav }) {
    const user = API.getUser();
    const rolePath = ROLE_PATHS[user.role] || 'student';

    // sidebar
    const sidebar = el(`<aside class="sidebar">
      <div class="brand">
        <div class="logo" id="brand-logo">${icon('school', { size: 20 })}</div>
        <div style="min-width:0">
          <div class="name" id="school-name">Kalinabiri SS</div>
          <div class="role-tag">${esc(user.role.replace('_', ' '))} portal</div>
        </div>
      </div>
      <nav id="side-nav"></nav>
      <button class="nav-item sidebar-logout" id="sidebar-logout"><span class="ic">${icon('logout', { size: 18 })}</span><span>Log out</span></button>
      <div class="sidebar-foot" id="school-motto">Kalinabiri Secondary School</div>
    </aside>`);
    const navWrap = sidebar.querySelector('#side-nav');
    let lastSection = null;
    for (const item of nav) {
      if (item.section !== lastSection) {
        lastSection = item.section;
        navWrap.appendChild(el(`<div class="nav-section">${esc(item.section)}</div>`));
      }
      navWrap.appendChild(el(
        `<button class="nav-item" data-nav="${esc(item.key)}"><span class="ic">${icon(item.icon, { size: 18 })}</span><span>${esc(item.label)}</span><span class="badge" data-nav-badge="${esc(item.key)}" style="display:none"></span></button>`
      ));
    }

    // topbar
    const topbar = el(`<div class="topbar">
      <button class="hamburger" id="hamburger" aria-label="Open sidebar" aria-expanded="false" title="Sidebar">${icon('sidebar', { size: 18 })}</button>
      <div class="page-title" id="page-title">${esc(title || 'Dashboard')}</div>
      <div class="global-search" id="global-search">
        <span class="gs-ic" aria-hidden="true">${icon('search', { size: 16 })}</span>
        <input type="search" id="gs-input" placeholder="Search students, staff, documents…" aria-label="Search the whole platform" autocomplete="off" enterkeyhint="search">
        <button class="gs-clear" id="gs-clear" type="button" aria-label="Clear search" title="Clear search" hidden>${icon('close', { size: 14 })}</button>
        <div class="gs-drop" id="gs-drop" role="listbox" aria-label="Search results" hidden></div>
      </div>
      <button class="icon-btn gs-mobile-btn" id="gs-mobile-btn" title="Search" aria-label="Search">${icon('search', { size: 18 })}</button>
      <div class="spacer"></div>
      <button class="icon-btn" id="theme-btn" title="Switch theme (light / dark / system)" aria-label="Switch theme">${icon('theme', { size: 18 })}</button>
      <button class="icon-btn topbar-logout" id="logout-btn" title="Log out" aria-label="Log out">${icon('logout', { size: 18 })}</button>
      <div class="dropdown" id="notif-drop">
        <button class="icon-btn" id="notif-btn" aria-label="Notifications">${icon('notifications', { size: 18 })}<span class="count-dot" id="notif-dot" style="display:none">0</span></button>
        <div class="dropdown-menu" id="notif-menu"></div>
      </div>
      <div class="dropdown" id="user-drop">
        <button class="user-chip" id="user-chip">
          <div class="avatar">${esc(initials(user.fullName))}</div>
          <div class="meta">
            <div class="u-name">${esc(user.fullName)}</div>
            <div class="u-role">${esc(user.role.replace('_', ' '))}</div>
          </div>
        </button>
        <div class="user-menu" id="user-menu">
          <div class="um-head"><strong>${esc(user.fullName)}</strong><br><small>${esc(user.email || '')}</small></div>
          <button class="um-item" data-um="profile">${icon('profile', { size: 16 })} My profile</button>
          <button class="um-item" data-um="photo">${icon('camera', { size: 16 })} Change photo</button>
          <button class="um-item" data-um="theme">${icon('theme', { size: 16 })} Theme: <span id="um-theme-label">System</span></button>
          <button class="um-item" data-um="password">${icon('key', { size: 16 })} Change password</button>
          <button class="um-item" data-um="notifications">${icon('notifications', { size: 16 })} Notifications</button>
          <button class="um-item danger" data-um="logout">${icon('logout', { size: 16 })} Log out</button>
        </div>
      </div>
    </div>`);

    const layout = el(`<div class="layout"></div>`);
    const main = el(`<main class="main"></main>`);
    const content = el(`<div class="content" id="content"></div>`);
    main.appendChild(topbar);
    main.appendChild(content);
    layout.appendChild(sidebar);
    layout.appendChild(main);
    document.body.appendChild(layout);

    // bottom nav — built on demand so rotating a phone (or resizing a window
    // across the breakpoint) does not leave the dashboard without navigation
    function buildBottomNav() {
      if (!bottomNav || document.getElementById('bottom-nav')) return;
      const bn = el('<div class="bottom-nav" id="bottom-nav"></div>');
      for (const item of bottomNav) {
        bn.appendChild(el(`<button class="bn-item" data-bn="${esc(item.key)}"><span class="ic">${icon(item.icon, { size: 18 })}</span><span>${esc(item.label)}</span><span class="bn-badge" data-bn-badge="${esc(item.key)}" style="display:none"></span></button>`));
      }
      document.body.appendChild(bn);
      bn.querySelectorAll('.bn-item').forEach((b) => b.addEventListener('click', () => {
        document.body.classList.remove('chat-open');
        onNav(b.dataset.bn);
        content.scrollTop = 0;
      }));
      // keep the badge in step with the sidebar
      if (typeof window.__syncBadges === 'function') window.__syncBadges();
    }
    if (window.innerWidth <= 768) buildBottomNav();
    let wasNarrow = window.innerWidth <= 768;
    window.addEventListener('resize', () => {
      const narrow = window.innerWidth <= 768;
      if (narrow === wasNarrow) return;
      wasNarrow = narrow;
      if (narrow) buildBottomNav();
      else { closeSidebar(); }
    }, { passive: true });

    // global search — lives in the topbar of every dashboard
    initGlobalSearch({ topbar, onNav });

    // events
    sidebar.querySelectorAll('.nav-item[data-nav]').forEach((b) => b.addEventListener('click', () => {
      document.body.classList.remove('chat-open');
      onNav(b.dataset.nav);
      closeSidebar();
    }));

    // mobile sidebar: hamburger + backdrop scrim + Escape all close it
    const scrim = el('<div class="sidebar-scrim" id="sidebar-scrim"></div>');
    document.body.appendChild(scrim);
    const anyOverlay = () => document.querySelectorAll('.sidebar-scrim, .mobile-overlay');
    const burgerBtn = topbar.querySelector('#hamburger');
    let sidebarLocked = false;
    function markSidebar(open) {
      burgerBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      burgerBtn.setAttribute('aria-label', open ? 'Close sidebar' : 'Open sidebar');
      burgerBtn.title = open ? 'Close sidebar' : 'Sidebar';
    }
    function openSidebar() {
      sidebar.classList.add('open');
      anyOverlay().forEach((o) => o.classList.add('open'));
      markSidebar(true);
      if (!sidebarLocked) { sidebarLocked = true; lockScroll(); }
    }
    function closeSidebar() {
      const wasOpen = sidebar.classList.contains('open') || sidebarLocked;
      sidebar.classList.remove('open');
      anyOverlay().forEach((o) => o.classList.remove('open'));
      markSidebar(false);
      if (sidebarLocked) { sidebarLocked = false; unlockScroll(); }
      return wasOpen;
    }
    // mark as bound so ux.js's fallback binder never double-binds this button
    burgerBtn.dataset.uxBound = '1';
    burgerBtn.onclick = () => {
      sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    };
    scrim.onclick = closeSidebar;
    document.addEventListener('click', (e) => {
      if (e.target.classList && e.target.classList.contains('mobile-overlay')) closeSidebar();
    });
    document.addEventListener('keydown', (e) => {
      // only when the drawer is really open, otherwise Escape would release the
      // scroll lock of an unrelated open dialog
      if (e.key === 'Escape' && sidebar.classList.contains('open')) closeSidebar();
    });

    // render avatar image if the user has a photo
    const chipAvatar = topbar.querySelector('#user-chip .avatar');
    const avUrl = avatarUrl(user);
    if (avUrl) {
      chipAvatar.innerHTML = `<img src="${avUrl}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`;
    }

    topbar.querySelector('#user-chip').onclick = (e) => {
      e.stopPropagation();
      topbar.querySelector('#user-menu').classList.toggle('open');
      topbar.querySelector('#notif-drop').classList.remove('open');
    };
    topbar.querySelector('#notif-btn').onclick = (e) => {
      e.stopPropagation();
      topbar.querySelector('#notif-drop').classList.toggle('open');
      topbar.querySelector('#user-menu').classList.remove('open');
      if (topbar.querySelector('#notif-drop').classList.contains('open')) renderNotifications();
    };
    const closeDropdowns = () => {
      topbar.querySelector('#user-menu').classList.remove('open');
      topbar.querySelector('#notif-drop').classList.remove('open');
    };
    document.addEventListener('click', closeDropdowns);
    // keyboard users expect Escape to dismiss the open menu too
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDropdowns(); });

    topbar.querySelector('#user-menu').querySelector('[data-um="logout"]').onclick = async () => {
      // API.logout() asks the server to revoke the session, then redirects.
      await API.logout();
    };
    topbar.querySelector('#user-menu').querySelector('[data-um="password"]').onclick = () => openChangePassword();
    topbar.querySelector('#user-menu').querySelector('[data-um="photo"]').onclick = () => openAvatarUpload();

    // theme switcher: cycles System -> Light -> Dark
    const themeLabel = topbar.querySelector('#um-theme-label');
    const refreshThemeLabel = () => { if (themeLabel) themeLabel.textContent = (window.Theme.current() || 'system').replace(/^\w/, (c) => c.toUpperCase()); };
    refreshThemeLabel();
    document.addEventListener('theme:changed', refreshThemeLabel);
    topbar.querySelector('#user-menu').querySelector('[data-um="theme"]').onclick = () => {
      const order = ['system', 'light', 'dark'];
      const next = order[(order.indexOf(window.Theme.current()) + 1) % order.length];
      window.Theme.set(next);
      refreshThemeLabel();
      UI.toast(`Theme: ${next}`, 'info');
    };
    topbar.querySelector('#user-menu').querySelector('[data-um="profile"]').onclick = () => onNav('profile');
    topbar.querySelector('#user-menu').querySelector('[data-um="notifications"]').onclick = () => onNav('notifications');

    // always-visible topbar buttons: theme toggle + logout
    const doLogout = async () => {
      const sure = await confirmDialog('Log out of your dashboard?', { title: 'Log out', confirmText: 'Log out' });
      if (!sure) return;
      // API.logout() asks the server to revoke the session, then redirects.
      await API.logout();
    };
    topbar.querySelector('#logout-btn').onclick = doLogout;
    const themeBtn = topbar.querySelector('#theme-btn');
    const themeIconName = () => ({ light: 'sun', dark: 'moon', system: 'theme' }[window.Theme.current() || 'system'] || 'theme');
    themeBtn.innerHTML = icon(themeIconName(), { size: 18 });
    themeBtn.onclick = () => {
      const order = ['system', 'light', 'dark'];
      const next = order[(order.indexOf(window.Theme.current()) + 1) % order.length];
      window.Theme.set(next);
      themeBtn.innerHTML = icon(themeIconName(), { size: 18 });
      refreshThemeLabel();
      UI.toast(`Theme: ${next}`, 'info');
    };
    document.addEventListener('theme:changed', () => { themeBtn.innerHTML = icon(themeIconName(), { size: 18 }); });

    // sidebar logout (same confirm flow as the topbar button)
    sidebar.querySelector('#sidebar-logout').onclick = doLogout;

    // school name + motto + logo (same identity as the public website)
    try {
      const s = await API.get('/api/settings/public');
      if (s.school && s.school.name) {
        sidebar.querySelector('#school-name').textContent = s.school.name;
        document.title = s.school.name + ' — ' + (user.role.replace('_', ' '));
        const motto = sidebar.querySelector('#school-motto');
        if (motto) motto.textContent = s.school.motto || s.school.name;
      }
    } catch { /* keep default */ }
    applySchoolLogo(sidebar.querySelector('#brand-logo'));

    const setBadge = (key, count) => {
      const b = sidebar.querySelector(`[data-nav-badge="${key}"]`);
      const bb = document.querySelector(`[data-bn-badge="${key}"]`);
      const show = count > 0;
      for (const node of [b, bb]) {
        if (!node) continue;
        node.style.display = show ? 'inline-flex' : 'none';
        node.textContent = count > 99 ? '99+' : count;
      }
    };

    // notification polling loop — the counts it fetches must actually reach the
    // sidebar / bottom-nav badges, otherwise a message that arrives while you
    // are on another screen never shows a badge anywhere.
    onUnreadChange(() => {
      const u = window.__unread || {};
      setBadge('messages', u.messages || 0);
      setBadge('notifications', u.notifications || 0);
    });
    // Counts only matter while somebody is looking: skip the poll in a hidden
    // tab and refresh immediately when the tab comes back, so returning to a
    // dashboard shows the current numbers instead of up to 30s-old ones.
    const unreadMs = Number(window.APP_CONFIG.UNREAD_POLL_MS) || 30000;
    const pollTick = () => { if (!document.hidden) refreshUnreadCounts(); };
    refreshUnreadCounts();
    setInterval(pollTick, unreadMs);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) return;
      refreshUnreadCounts();
      refreshInboxBadges();
    });

    // Website intake badges: the two public-form inboxes must advertise
    // themselves on the sidebar/bottom nav, otherwise a parent's application
    // can sit unseen until somebody happens to open that section.
    async function refreshInboxBadges() {
      try {
        const o = await API.get('/api/stats/overview');
        const w = (o && o.counts && o.counts.website) || null;
        if (!w) return;                       // not an office role
        setBadge('website-contact', w.contactNew || 0);
        setBadge('admissions', w.admissionsNew || 0);
      } catch { /* offline / not permitted — leave the badges as they are */ }
    }
    refreshInboxBadges();
    setInterval(() => { if (!document.hidden) refreshInboxBadges(); }, 60000);

    // "Try again" on the connection notice reloads the section the user is
    // looking at, so a view that failed while the network was down recovers
    // without the user having to guess which tab to press.
    let currentKey = null;
    const retryCurrent = () => { if (currentKey) onNav(currentKey); };
    if (window.NetStatus && !window.__netRetryWired) {
      window.__netRetryWired = true;
      window.NetStatus.onRetry(() => {
        if (navigator.onLine === false) return;     // nothing to retry yet
        retryCurrent();
        refreshUnreadCounts();
      });
      window.addEventListener('online', () => { retryCurrent(); });
    }

    return {
      content,
      setTitle: (t) => { topbar.querySelector('#page-title').textContent = t; },
      setActive: (key) => {
        currentKey = key;
        sidebar.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.nav === key));
        document.querySelectorAll('.bn-item').forEach((b) => b.classList.toggle('active', b.dataset.bn === key));
      },
      setBadge,
      sidebar,
      retryCurrent,
    };
  }

  async function renderNotifications() {
    const menu = document.querySelector('#notif-menu');
    if (!menu) return;
    const items = await loadNotifications();
    const icons = { message: 'messages', document: 'document', announcement: 'announcements', system: 'notifications', account: 'lock' };
    if (!items.length) {
      menu.innerHTML = `<div class="empty-state" style="padding:30px"><div class="big">${icon('bellOff', { size: 22 })}</div>No notifications yet</div>`;
      return;
    }
    menu.innerHTML = `<div style="padding:12px 14px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
        <strong>Notifications</strong>
        <button class="btn ghost sm" id="mark-all">Mark all read</button></div>`;
    for (const n of items) {
      menu.appendChild(el(`<div class="notif-item ${n.read ? '' : 'unread'}" data-nid="${n.id}" data-link="${esc(n.link || '')}">
        <span class="n-ic">${icon(icons[n.type] || 'notifications', { size: 16 })}</span>
        <div><div class="n-title">${esc(n.title)}</div>
        ${n.body ? `<div class="n-body">${esc(n.body)}</div>` : ''}
        <div class="n-time">${timeAgo(n.created_at)}</div></div></div>`));
    }
    menu.querySelectorAll('.notif-item').forEach((item) => item.addEventListener('click', async () => {
      const id = item.dataset.nid;
      const link = item.dataset.link;
      try { await API.put(`/api/notifications/${id}/read`); } catch {}
      item.classList.remove('unread');
      refreshUnreadCounts();
      if (link) navigateToLink(link);
    }));
    menu.querySelector('#mark-all').onclick = async () => {
      try { await API.put('/api/notifications/read-all'); } catch {}
      menu.querySelectorAll('.notif-item').forEach((i) => i.classList.remove('unread'));
      refreshUnreadCounts();
    };
  }

  /**
   * A failed view must SAY SO. Before this, a dropped connection left the panel
   * showing its loading skeleton forever and threw an unhandled rejection into
   * the console, so a teacher whose signal dropped saw a dashboard that simply
   * stopped working. Every view object exposed by a component is wrapped here:
   * any failure renders a short explanation with a Try again button.
   */
  function renderViewError(box, err, retry) {
    if (!box || !box.isConnected) return;
    const offline = err && (err.code === 'NETWORK' || err.code === 'TIMEOUT');
    const message = offline
      ? 'Cannot reach the school server. Check your connection — nothing here has been lost.'
      : ((err && err.message) || 'Something went wrong while opening this section.');
    const card = el(`<div class="card" style="border-left:4px solid var(--danger,#dc2626)">
      <h3 style="margin:0 0 4px">${esc(offline ? 'No connection' : 'Could not open this section')}</h3>
      <div class="doc-meta">${esc(message)}</div>
      <button type="button" class="btn btn-sm" style="margin-top:10px">Try again</button>
    </div>`);
    card.querySelector('button').addEventListener('click', async (ev) => {
      const btn = ev.currentTarget;
      btn.disabled = true;
      btn.textContent = 'Retrying…';
      try { await retry(); } catch { /* the guard will render the error again */ }
      btn.disabled = false;
      btn.textContent = 'Try again';
    });
    box.innerHTML = '';
    box.appendChild(card);
  }

  /**
   * Wrap a component's view objects so every method fails visibly, never
   * silently. Non-object values (helpers like attBadge) pass straight through.
   */
  function guardViews(api) {
    const guarded = {};
    for (const [name, view] of Object.entries(api || {})) {
      if (!view || typeof view !== 'object') { guarded[name] = view; continue; }
      guarded[name] = {};
      for (const [method, fn] of Object.entries(view)) {
        if (typeof fn !== 'function') { guarded[name][method] = fn; continue; }
        guarded[name][method] = async function guardedView(box, ...rest) {
          try {
            return await fn.call(this, box, ...rest);
          } catch (e) {
            if (window.NetStatus && (e.code === 'NETWORK' || e.code === 'TIMEOUT')) window.NetStatus.offline();
            else toast(e.message || 'Something went wrong.', 'error');
            renderViewError(box, e, () => guarded[name][method].call(guarded[name], box, ...rest));
          }
        };
      }
    }
    return guarded;
  }

  /**
   * Follow a notification link. Links are dashboard section keys written as
   * paths ("/website-contact"). Two things used to break a click:
   *   1. the key did not exist on that role's dashboard (a parent gets an
   *      attendance alert but has no "attendance" tab — the child's record is
   *      under "children"), and
   *   2. a genuinely wrong key (e.g. "/contact-messages") navigated nowhere.
   * So resolve the intended section through an alias ladder, and if nothing
   * matches, fall back to a view every dashboard has.
   */
  const LINK_ALIASES = {
    exams: ['exams', 'results', 'children'],
    results: ['results', 'exams', 'children'],
    attendance: ['attendance', 'children'],
    fees: ['fees', 'children'],
    parents: ['parents', 'users'],
    users: ['users', 'parents'],
    admissions: ['admissions', 'website-contact', 'messages'],
    'contact-messages': ['website-contact', 'messages'],
    'website-contact': ['website-contact', 'messages'],
    documents: ['documents', 'children'],
    assignments: ['assignments', 'children'],
  };
  function hasSection(key) {
    return !!document.querySelector(`.nav-item[data-nav="${key}"], .bn-item[data-bn="${key}"]`);
  }
  function navigateToLink(link) {
    const handler = window.__navHandler;
    if (typeof handler !== 'function') return;
    const key = String(link || '').replace(/^\//, '').split('?')[0].split('#')[0];
    if (!key) return;
    const ladder = [key, ...(LINK_ALIASES[key] || [])];
    const target = ladder.find(hasSection)
      || ['messages', 'notifications', 'home'].find(hasSection);
    if (target) handler(target);
  }

  // ---------------- profile picture ----------------
  function openAvatarUpload() {
    const input = el('<input type="file" accept="image/jpeg,image/png,image/gif,image/webp,image/bmp" hidden>');
    document.body.appendChild(input);
    input.click();
    input.onchange = async () => {
      const file = input.files[0];
      if (!file) return;
      if (file.size > 2 * 1024 * 1024) return toast('Image is too large. Maximum is 2 MB.', 'error');
      const form = new FormData();
      form.append('file', file);
      try {
        const r = await API.upload('/api/auth/profile-picture', form);
        const updated = r.user || null;
        if (updated) API.setUser(updated);
        toast('Profile picture updated.', 'success');
        location.reload();
      } catch (e) { toast(e.message, 'error'); }
    };
  }

  // ---------------- preferences panel (theme + notifications) ----------------
  const NOTIF_KEYS = [
    ['newMessage', 'New messages'],
    ['newDocument', 'New documents'],
    ['newAnnouncement', 'Announcements'],
    ['assignments', 'Assignments & deadlines'],
    ['attendance', 'Attendance alerts'],
    ['exams', 'Exam announcements'],
    ['results', 'Results & grades'],
    ['fees', 'Fee updates'],
    ['importantNotices', 'Important notices'],
    ['accountChanges', 'Account changes'],
  ];

  /**
   * Render the personal settings panel (theme + notification toggles) into a
   * container and wire it up. Used by every dashboard's Profile view.
   */
  async function profileSettingsPanel(container) {
    let prefs = { theme: 'system', notifPrefs: {} };
    try { prefs = (await API.get('/api/auth/preferences')).preferences; } catch {}

    container.innerHTML = `
      <div class="card">
        <h3>${icon('theme', { size: 16 })} Appearance</h3>
        <p class="doc-meta">Choose how the platform looks. Your choice is saved and follows you on every device.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="chip" data-theme-opt="system">System</button>
          <button class="chip" data-theme-opt="light">${icon('sun', { size: 14 })} Light</button>
          <button class="chip" data-theme-opt="dark">${icon('moon', { size: 14 })} Dark</button>
        </div>
      </div>
      <div class="card">
        <h3>${icon('notifications', { size: 16 })} Notification preferences</h3>
        <p class="doc-meta">Choose which notifications you receive. The school can also set defaults.</p>
        <div id="notif-prefs-list"></div>
        <button class="btn" id="prefs-save" style="margin-top:12px">${icon('save', { size: 14 })} Save preferences</button>
      </div>`;

    const themeOpts = container.querySelectorAll('[data-theme-opt]');
    const refresh = () => themeOpts.forEach((b) => b.classList.toggle('active', b.dataset.themeOpt === window.Theme.current()));
    refresh();
    themeOpts.forEach((b) => b.addEventListener('click', () => { window.Theme.set(b.dataset.themeOpt); refresh(); }));

    const list = container.querySelector('#notif-prefs-list');
    for (const [key, label] of NOTIF_KEYS) {
      list.appendChild(el(`<div class="list-row"><span class="k">${esc(label)}</span>
        <input type="checkbox" data-np="${key}" ${prefs.notifPrefs[key] !== false ? 'checked' : ''} style="width:auto;margin:0"></div>`));
    }
    container.querySelector('#prefs-save').onclick = async () => {
      const notifPrefs = {};
      list.querySelectorAll('[data-np]').forEach((i) => { notifPrefs[i.dataset.np] = i.checked; });
      try {
        await API.put('/api/auth/preferences', { theme: window.Theme.current(), notifPrefs });
        toast('Preferences saved.', 'success');
      } catch (e) { toast(e.message, 'error'); }
    };
  }

  // ---------------- change password / profile ----------------
  function openChangePassword() {
    // openModal() returns the modal control object synchronously — it is not a
    // promise, so the handlers are bound here and not in a .then().
    const m = openModal({
      title: 'Change password',
      body: `<label class="field">Current password<input type="password" id="pw-current" autocomplete="current-password"></label>
             <label class="field">New password<input type="password" id="pw-new" autocomplete="new-password"></label>
             <label class="field">Confirm new password<input type="password" id="pw-confirm" autocomplete="new-password"></label>
             <p class="doc-meta" style="margin:0">Use at least 8 characters. You will stay signed in on this device.</p>`,
      foot: `<button class="btn secondary" data-cancel>Cancel</button><button class="btn" data-save>Update password</button>`,
    });
    const cancel = m.backdrop.querySelector('[data-cancel]');
    const save = m.backdrop.querySelector('[data-save]');
    if (!cancel || !save) return;
    cancel.onclick = () => m.close();
    save.onclick = async () => {
      const cur = m.backdrop.querySelector('#pw-current').value;
      const nw = m.backdrop.querySelector('#pw-new').value;
      const cf = m.backdrop.querySelector('#pw-confirm').value;
      if (!cur || !nw) return toast('Enter your current and new password.', 'error');
      if (nw !== cf) return toast('New passwords do not match.', 'error');
      save.disabled = true;
      try {
        await API.put('/api/auth/change-password', { currentPassword: cur, newPassword: nw });
        toast('Password updated successfully.', 'success');
        m.close();
      } catch (e) {
        toast(e.message, 'error');
      } finally {
        save.disabled = false;
      }
    };
  }

  // expose
  window.UI = {
    esc, el, initials, avatar, avatarUrl, logoUrl, applySchoolLogo,
    timeAgo, fmtTime, fmtDate, fmtSize,
    debounce, money, barChart,
    toast, openModal, modal: openModal, confirmDialog,
    initLayout, refreshUnreadCounts, loadNotifications,
    onUnreadChange, openChangePassword, openAvatarUpload, profileSettingsPanel, openPrintable,
    lockScroll, unlockScroll,
    navigateToLink,   // used by the notification bell; exported so it can be tested
    guardViews, renderViewError,
  };
})();
