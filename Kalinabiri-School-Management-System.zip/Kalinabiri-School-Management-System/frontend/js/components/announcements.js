/**
 * Announcements component — read/unread list with an optional composer
 * for admins and teachers.
 */
(function () {
  const API = window.API;
  const UI = window.UI;

  class AnnouncementsView {
    constructor({ container, canPost = false, teacherMode = false }) {
      this.container = container;
      this.canPost = canPost;
      this.teacherMode = teacherMode;
    }

    async render() {
      this.container.innerHTML = `
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;flex-wrap:wrap">
          <h2 style="margin:0;flex:1">Announcements</h2>
          ${this.canPost ? '<button class="btn" id="ann-new"><svg class="ie" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-0.12em" aria-hidden="true"><path d="M3 11v2a1 1 0 0 0 1 1h2l4 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M14.5 8.5a5 5 0 0 1 0 7"/><path d="M17.5 5.5a9 9 0 0 1 0 13"/></svg> New announcement</button>' : ''}
        </div>
        <div id="ann-list"></div>`;

      if (this.canPost) this.container.querySelector('#ann-new').onclick = () => this.compose();
      await this.load();
    }

    async load() {
      try {
        const data = await API.get('/api/announcements');
        const list = this.container.querySelector('#ann-list');
        if (!list) return;
        const items = data.announcements || [];
        if (!items.length) {
          list.innerHTML = `<div class="empty-state"><div class="big"><svg class="ie" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-0.12em" aria-hidden="true"><path d="M3 11v2a1 1 0 0 0 1 1h2l4 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M14.5 8.5a5 5 0 0 1 0 7"/><path d="M17.5 5.5a9 9 0 0 1 0 13"/></svg></div>No announcements yet.</div>`;
        } else {
          list.innerHTML = '';
          for (const a of items) list.appendChild(this.item(a));
        }
        window.__setNavBadge && window.__setNavBadge('announcements', data.unread || 0);
      } catch (e) { UI.toast(e.message, 'error'); }
    }

    item(a) {
      const important = !!a.important;
      const item = UI.el(`<div class="ann-item ${a.is_read ? '' : 'unread'} ${important ? 'important' : ''}">
        <div class="ann-title">
          ${important ? '<span class="badge red">IMPORTANT</span>' : ''}
          ${a.status === 'scheduled' ? '<span class="badge amber">SCHEDULED</span>' : ''}
          <span>${UI.esc(a.title)}</span>
        </div>
        <div class="ann-meta">${important ? '<svg class="ie" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-0.12em" aria-hidden="true"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg> ' : ''}${UI.esc(a.sender_name || 'School')} · ${UI.fmtDate(a.created_at)} · ${UI.timeAgo(a.created_at)}
          ${a.status === 'scheduled' ? `· goes out ${UI.esc(String(a.scheduled_at || '').replace('T', ' '))}` : ''}
          ${this.canPost ? `<button class="btn ghost sm" data-edit style="margin-left:8px"><svg class="ie" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-0.12em" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg> Edit</button><button class="btn ghost sm" data-del>Delete</button>` : ''}
        </div>
        <div class="ann-body">${UI.esc(a.content)}</div>
      </div>`);
      if (!a.is_read) {
        item.addEventListener('click', async () => {
          try { await API.put(`/api/announcements/${a.id}/read`); item.classList.remove('unread'); this.load(); } catch {}
        });
      }
      const del = item.querySelector('[data-del]');
      if (del) del.onclick = async (e) => {
        e.stopPropagation();
        const ok = await UI.confirmDialog(`Delete announcement "${a.title}"?`, { title: 'Delete announcement', confirmText: 'Delete' });
        if (!ok) return;
        try { await API.del(`/api/announcements/${a.id}`); UI.toast('Announcement deleted.', 'success'); this.load(); }
        catch (err) { UI.toast(err.message, 'error'); }
      };
      const edit = item.querySelector('[data-edit]');
      if (edit) edit.onclick = (e) => {
        e.stopPropagation();
        this.edit(a);
      };
      return item;
    }

    /**
     * Read the chosen audience from the target <select>.
     *
     * The option values are JSON. Teachers get a blank "Select a class…"
     * placeholder first, so an unguarded JSON.parse('') used to throw an
     * unhandled error and the Publish button appeared to do nothing at all.
     */
    parseTarget(sel) {
      const raw = sel ? String(sel.value || '').trim() : '';
      if (!raw) return { error: 'Choose who this announcement is for.' };
      try {
        const v = JSON.parse(raw);
        if (!v || typeof v !== 'object' || !v.targetType) return { error: 'Choose who this announcement is for.' };
        return { targetType: v.targetType, targetValue: v.targetValue === undefined ? '' : v.targetValue };
      } catch {
        return { error: 'Choose who this announcement is for.' };
      }
    }

    async compose() {
      const options = await this.targetOptions();
      let modal;
      modal = UI.openModal({
        title: 'New announcement',
        wide: true,
        body: `
          <label class="field">Title <span class="req">*</span><input id="ann-title" maxlength="200"></label>
          <label class="field">Message <span class="req">*</span><textarea id="ann-content" rows="5"></textarea></label>
          <label class="field">Target audience
            <select id="ann-target">${options}</select></label>
          <label class="field" style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="ann-important" style="width:auto;margin:0"> Mark as important</label>
          <label class="field">Schedule for later <span class="doc-meta">(leave empty to publish now)</span>
            <input type="datetime-local" id="ann-when"></label>
          <div class="doc-meta">A scheduled notice is hidden from everyone until that time, then it publishes and notifies by itself.</div>`,
        foot: `<button class="btn secondary" data-cancel>Cancel</button><button class="btn secondary" data-schedule>Schedule</button><button class="btn" data-send>Publish</button>`,
      });
      modal.backdrop.querySelector('[data-cancel]').onclick = () => modal.close();
      const submit = async ({ schedule }) => {
        const title = modal.backdrop.querySelector('#ann-title').value.trim();
        const content = modal.backdrop.querySelector('#ann-content').value.trim();
        if (!title || !content) return UI.toast('Title and message are required.', 'error');
        const sel = modal.backdrop.querySelector('#ann-target');
        const target = this.parseTarget(sel);
        if (target.error) return UI.toast(target.error, 'error');
        const important = modal.backdrop.querySelector('#ann-important').checked;
        const when = modal.backdrop.querySelector('#ann-when').value;
        if (schedule && !when) return UI.toast('Choose the date and time to publish.', 'error');
        if (when && new Date(when).getTime() <= Date.now() && schedule) {
          return UI.toast('That time has already passed — pick a future time or press Publish.', 'error');
        }
        try {
          const r = await API.post('/api/announcements', {
            title, content,
            targetType: target.targetType,
            targetValue: target.targetValue,
            important,
            scheduledAt: when || undefined,
          });
          UI.toast(r.message || 'Announcement published.', 'success');
          modal.close();
          await this.load();
        } catch (e) { UI.toast(e.message, 'error'); }
      };
      modal.backdrop.querySelector('[data-send]').onclick = () => submit({ schedule: false });
      modal.backdrop.querySelector('[data-schedule]').onclick = () => submit({ schedule: true });
    }

    /** Edit an existing announcement (sender or admin — the API enforces it). */
    async edit(a) {
      const options = await this.targetOptions();
      const targetVal = a.target_value || '';
      const targetType = a.target_type || 'all';
      let modal;
      modal = UI.openModal({
        title: 'Edit announcement',
        wide: true,
        body: `
          <label class="field">Title <span class="req">*</span><input id="ann-title" maxlength="200" value="${UI.esc(a.title)}"></label>
          <label class="field">Message <span class="req">*</span><textarea id="ann-content" rows="5">${UI.esc(a.content)}</textarea></label>
          <label class="field">Target audience <select id="ann-target">${options}</select></label>
          <label class="field" style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="ann-important" style="width:auto;margin:0" ${a.important ? 'checked' : ''}> Mark as important</label>
          <label class="field">Schedule for <span class="doc-meta">${a.status === 'scheduled' ? '(not published yet)' : '(leave empty if already published)'}</span>
            <input type="datetime-local" id="ann-when" value="${UI.esc(String(a.scheduled_at || '').replace(' ', 'T').slice(0, 16))}"></label>`,
        foot: `<button class="btn secondary" data-cancel>Cancel</button><button class="btn" data-save>Save changes</button>`,
      });
      const sel = modal.backdrop.querySelector('#ann-target');
      if (!sel) { modal.close(); return UI.toast('Could not open the editor. Reload the page and try again.', 'error'); }
      // preselect the current target
      for (const opt of sel.options) {
        try {
          const v = JSON.parse(opt.value);
          if (v.targetType === targetType && String(v.targetValue || '') === String(targetVal)) opt.selected = true;
        } catch {}
      }
      modal.backdrop.querySelector('[data-cancel]').onclick = () => modal.close();
      modal.backdrop.querySelector('[data-save]').onclick = async () => {
        const title = modal.backdrop.querySelector('#ann-title').value.trim();
        const content = modal.backdrop.querySelector('#ann-content').value.trim();
        if (!title || !content) return UI.toast('Title and message are required.', 'error');
        const target = this.parseTarget(sel);
        if (target.error) return UI.toast(target.error, 'error');
        try {
          await API.put(`/api/announcements/${a.id}`, {
            title,
            content,
            important: modal.backdrop.querySelector('#ann-important').checked,
            targetType: target.targetType,
            targetValue: target.targetValue,
            scheduledAt: modal.backdrop.querySelector('#ann-when').value || '',
          });
          UI.toast('Announcement updated.', 'success');
          modal.close();
          await this.load();
        } catch (e) { UI.toast(e.message, 'error'); }
      };
    }

    async targetOptions() {
      let classes = [];
      try {
        // teachers may only announce to their own classes — the API enforces it too
        classes = this.teacherMode
          ? (await API.get('/api/classes')).classes || []
          : (await API.get('/api/settings/classes-reference')).classes || [];
      } catch {}
      const opts = [];
      if (!this.teacherMode) {
        opts.push(
          '<option value=\'{"targetType":"all","targetValue":""}\'>Everyone (whole school)</option>',
          '<option value=\'{"targetType":"role","targetValue":"student"}\'>All students</option>',
          '<option value=\'{"targetType":"role","targetValue":"parent"}\'>All parents</option>',
          '<option value=\'{"targetType":"role","targetValue":"teacher"}\'>All teachers</option>',
          '<option value=\'{"targetType":"staff","targetValue":""}\'>All staff (teachers + admins)</option>'
        );
      } else {
        opts.push('<option value="">Select a class…</option>');
      }
      for (const c of classes) {
        opts.push(`<option value='{"targetType":"class","targetValue":${c.id}}'>Class — ${UI.esc(c.name)} ${UI.esc(c.stream)}</option>`);
        opts.push(`<option value='{"targetType":"parents_of_class","targetValue":${c.id}}'>Parents of ${UI.esc(c.name)} ${UI.esc(c.stream)}</option>`);
      }
      return opts.join('');
    }
  }

  window.AnnouncementsView = AnnouncementsView;
})();
