/**
 * /api/imports — bulk student import (Excel / CSV) with administrator review.
 *
 * Workflow (each step is its own endpoint so the UI can walk the admin through):
 *  1. upload  -> parse file, return headers + sample rows + importId
 *  2. analyze -> (client) choose column mapping
 *  3. validate -> per-row validation: missing fields, duplicates, bad dates,
 *                 unknown classes, invalid phones/emails
 *  4. preview -> same validation data (client renders)
 *  5. import  -> transactional insert of valid records; skips errors safely
 *  6. report  -> counts + downloadable CSV of failures
 *
 * Extracted data is NEVER written to the database before the admin confirms.
 * Every import is recorded in the imports table (audit).
 */
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { readSpreadsheet, SUPPORTED_EXTENSIONS, DANGEROUS_KEYS } = require('../services/spreadsheet');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { all, get, run, tx } = require('../database/db');
const env = require('../config/env');
const { authenticate, requireStaffAdmin } = require('../middleware/auth');
const { upload, handleUploadErrors } = require('../middleware/upload');
const { cleanString, isEmail, isPhone, asInt } = require('../middleware/validate');
const { log } = require('../services/audit');

const IMPORT_TYPES = SUPPORTED_EXTENSIONS; // csv, xlsx
const LEGACY_XLS_HINT = 'Legacy Excel .xls files are not supported. In Excel choose File \u2192 Save As \u2192 Excel Workbook (.xlsx) or CSV, then upload that.';
const UNSUPPORTED_HINT = 'Only Excel (.xlsx) and CSV (.csv) files are supported.';
const MAX_ROWS = 5000;

// In-memory cache of parsed import sessions (survives the wizard steps).
const sessions = new Map();
function session(id) { return sessions.get(id); }
function putSession(s) { sessions.set(s.id, s); setTimeout(() => sessions.delete(s.id), 60 * 60 * 1000); return s; }

const FIELD_LABELS = {
  fullName: 'Full name',
  firstName: 'First name',
  lastName: 'Last name',
  studentCode: 'Student ID',
  className: 'Class',
  stream: 'Stream',
  gender: 'Gender',
  dateOfBirth: 'Date of birth',
  parentName: 'Parent/guardian name',
  parentPhone: 'Parent phone',
  parentEmail: 'Parent email',
  address: 'Address',
  enrollmentDate: 'Enrollment date',
  username: 'Login username',
  password: 'Login password',
};

/** Format a JS date as YYYY-MM-DD (local). */
function isoDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function normalizeDate(v) {
  if (v === undefined || v === null || v === '') return { value: null };
  // Excel often converts CSV date cells into serial numbers (e.g. 40179).
  if (typeof v === 'number') {
    const days = Math.floor(v);
    if (days >= 1 && days <= 80000) {
      const d = new Date(Math.round((days - 25569) * 86400 * 1000));
      if (!isNaN(d.getTime())) return { value: isoDate(d), normalized: true };
    }
    return { error: `Invalid date value "${v}"` };
  }
  const s = String(v).trim();
  if (/^\d{4,5}$/.test(s)) {
    // serial date arriving as a numeric string
    const days = parseInt(s, 10);
    const d = new Date(Math.round((days - 25569) * 86400 * 1000));
    if (days >= 1 && days <= 80000 && !isNaN(d.getTime())) return { value: isoDate(d), normalized: true };
    return { error: `Invalid date value "${s}"` };
  }
  let m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (m) {
    const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    if (d.getFullYear() === Number(m[1]) && d.getMonth() === Number(m[2]) - 1) return { value: s };
    return { error: 'Invalid date' };
  }
  m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s);
  if (m) {
    const d = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
    if (d.getDate() === Number(m[1])) {
      return { value: `${m[3]}-${m[2]}-${m[1]}`, normalized: true };
    }
    return { error: 'Invalid date' };
  }
  return { error: `Unrecognised date format "${s}"` };
}

function classForName(name, stream, academicYear) {
  if (!name) return null;
  const n = String(name).trim();
  const s = (stream || '').trim() || 'A';
  const direct = get('SELECT id FROM classes WHERE name = ? AND stream = ? AND academic_year = ?', [n, s, academicYear]);
  if (direct) return direct.id;
  // try name containing stream, e.g. "Senior 2 A"
  const m = /^(.*?)\s+([A-Z])$/.exec(n);
  if (m) {
    const alt = get('SELECT id FROM classes WHERE name = ? AND stream = ? AND academic_year = ?', [m[1].trim(), m[2], academicYear]);
    if (alt) return alt.id;
  }
  const fallback = get('SELECT id FROM classes WHERE name = ? AND academic_year = ?', [n, academicYear]);
  if (fallback) return fallback.id;
  return null;
}

/** Friendly reason why a file could not be read (legacy .xls gets its own hint). */
function unsupportedMessage(ext) {
  return ext === 'xls' ? LEGACY_XLS_HINT : UNSUPPORTED_HINT;
}

/** Read an uploaded spreadsheet (.csv / .xlsx) into header-keyed row objects. */
function readRows(filePath, ext) {
  return readSpreadsheet(filePath, ext);
}

// ---------------------------------------------------------------------------
// Step 1 — upload & parse
// ---------------------------------------------------------------------------
router.post('/upload', authenticate, requireStaffAdmin, upload.single('file'), handleUploadErrors, async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a file to upload.' });
  const ext = (req.file.originalname.split('.').pop() || '').toLowerCase();
  if (!IMPORT_TYPES.includes(ext)) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: unsupportedMessage(ext) });
  }
  const size = fs.statSync(req.file.path).size;
  if (size > 5 * 1024 * 1024) {
    fs.unlinkSync(req.file.path);
    return res.status(413).json({ error: 'File is too large. Maximum is 5 MB.' });
  }

  let rows;
  try {
    rows = await readRows(req.file.path, ext);
  } catch (e) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: 'Unable to read that file. Check that it is a valid spreadsheet and try again.' });
  }
  fs.unlinkSync(req.file.path);

  if (!rows.length) return res.status(400).json({ error: 'The file contains no data rows.' });
  if (rows.length > MAX_ROWS) return res.status(400).json({ error: `Too many rows (${rows.length}). Maximum is ${MAX_ROWS}.` });

  // Normalise headers to keys
  const headers = Object.keys(rows[0] || {});
  const normalized = rows.map((r) => {
    const o = {};
    for (const h of headers) {
      const val = r[h];
      o[String(h).trim()] = val === undefined ? '' : (typeof val === 'number' ? val : String(val).trim());
    }
    return o;
  });

  const id = crypto.randomBytes(8).toString('hex');
  const info = run('INSERT INTO imports (filename, kind, status, created_by) VALUES (?, ?, \'uploaded\', ?)', [req.file.originalname, 'students', req.user.id]);
  const sess = putSession({
    id,
    kind: 'students',
    filename: req.file.originalname,
    headers,
    rows: normalized,
    total: normalized.length,
    importDbId: info.lastInsertRowid,
    createdAt: Date.now(),
  });

  log(req.user, 'IMPORT_UPLOADED', `Uploaded "${req.file.originalname}" (${normalized.length} rows) for review`, req.ip);
  res.json({
    importId: id,
    importDbId: info.lastInsertRowid,
    filename: req.file.originalname,
    headers,
    total: normalized.length,
    sample: normalized.slice(0, 5),
    fields: FIELD_LABELS,
  });
});

// ---------------------------------------------------------------------------
// Steps 3 & 4 — validate / preview
// ---------------------------------------------------------------------------
router.post('/validate', authenticate, requireStaffAdmin, (req, res) => {
  const sess = session(cleanString(req.body.importId, 40));
  if (!sess) return res.status(404).json({ error: 'Import session expired. Upload the file again.' });
  const mapping = req.body.mapping || {};
  const academicYear = cleanString(req.body.academicYear, 20) || '2026';

  const results = sess.rows.map((row, index) => validateRow(row, mapping, academicYear, index, sess));
  const summary = summarize(results);
  run('UPDATE imports SET status = \'validated\', counts = ? WHERE id = ?',
    [JSON.stringify({ valid: summary.valid, errors: summary.errors, warnings: summary.warnings }), sess.importDbId || 0]);
  res.json({ rows: results, summary });
});

router.post('/preview', authenticate, requireStaffAdmin, (req, res) => {
  const sess = session(cleanString(req.body.importId, 40));
  if (!sess) return res.status(404).json({ error: 'Import session expired. Upload the file again.' });
  const mapping = req.body.mapping || {};
  const academicYear = cleanString(req.body.academicYear, 20) || '2026';
  const limit = Math.min(parseInt(req.body.limit || '50', 10) || 50, 200);
  const results = sess.rows.slice(0, limit).map((row, index) => validateRow(row, mapping, academicYear, index, sess));
  res.json({ rows: results, summary: summarize(results), total: sess.total });
});

function validateRow(row, mapping, academicYear, index, sess) {
  const errors = [];
  const warnings = [];
  const data = {};

  const fullName = firstNonEmpty(mapping.fullName && row[mapping.fullName], mapping.firstName && row[mapping.firstName], mapping.lastName && row[mapping.lastName]);
  data.fullName = fullName;
  if (!fullName) errors.push('Missing full name');

  const firstName = mapping.firstName ? row[mapping.firstName] : '';
  const lastName = mapping.lastName ? row[mapping.lastName] : '';
  if (mapping.firstName && !firstName) errors.push('Missing first name');
  if (mapping.lastName && !lastName) errors.push('Missing last name');

  data.studentCode = mapping.studentCode ? row[mapping.studentCode] : '';
  if (data.studentCode) {
    // Keep the FIRST occurrence of a duplicate ID; flag only later rows.
    const dupInFile = sess.rows.slice(0, index).some((r, i) => r[mapping.studentCode] && r[mapping.studentCode] === data.studentCode);
    if (dupInFile) errors.push(`Duplicate student ID "${data.studentCode}" in file`);
    else if (get('SELECT id FROM students WHERE student_code = ?', [data.studentCode])) errors.push(`Student ID "${data.studentCode}" already exists`);
  } else {
    warnings.push('No student ID — one will be auto-generated');
  }

  data.className = mapping.className ? row[mapping.className] : '';
  data.stream = mapping.stream ? row[mapping.stream] : '';
  const classId = classForName(data.className, data.stream, academicYear);
  if (data.className && !classId) {
    errors.push(`Unknown class "${data.className}" — create it first or fix the value`);
  } else if (!data.className) {
    warnings.push('No class — student will be unassigned');
  }
  data.classId = classId;

  data.gender = mapping.gender ? row[mapping.gender] : '';
  if (data.gender && !['Male', 'Female', 'M', 'F', 'male', 'female', 'm', 'f'].includes(data.gender)) {
    warnings.push(`Unrecognised gender "${data.gender}" — leave blank to correct`);
  }

  const dob = normalizeDate(mapping.dateOfBirth ? row[mapping.dateOfBirth] : '');
  if (dob.error) errors.push(`Invalid date of birth: ${dob.error}`);
  else if (dob.value) { data.dateOfBirth = dob.value; if (dob.normalized) warnings.push('Date of birth converted to YYYY-MM-DD'); }
  data.dateOfBirth = data.dateOfBirth || '';

  data.parentName = mapping.parentName ? row[mapping.parentName] : '';
  data.parentPhone = mapping.parentPhone ? row[mapping.parentPhone] : '';
  if (data.parentPhone && !isPhone(data.parentPhone)) warnings.push(`Invalid parent phone "${data.parentPhone}"`);
  data.parentEmail = mapping.parentEmail ? row[mapping.parentEmail] : '';
  if (data.parentEmail && !isEmail(data.parentEmail)) warnings.push(`Invalid parent email "${data.parentEmail}"`);
  data.address = mapping.address ? row[mapping.address] : '';

  const enr = normalizeDate(mapping.enrollmentDate ? row[mapping.enrollmentDate] : '');
  if (enr.error) errors.push(`Invalid enrollment date: ${enr.error}`);
  data.enrollmentDate = enr.value || '';

  data.username = mapping.username ? row[mapping.username] : '';
  data.password = mapping.password ? row[mapping.password] : '';
  if (data.username && data.password && data.password.length < 8) warnings.push('Password shorter than 8 characters');
  if (data.username && get('SELECT id FROM users WHERE username = ?', [data.username])) errors.push(`Username "${data.username}" already exists`);

  const status = errors.length ? 'error' : (warnings.length ? 'warning' : 'valid');
  return { index, data, status, errors, warnings };
}

function summarize(results) {
  return {
    total: results.length,
    valid: results.filter((r) => r.status === 'valid').length,
    warnings: results.filter((r) => r.status === 'warning').length,
    errors: results.filter((r) => r.status === 'error').length,
  };
}

function firstNonEmpty(...vals) {
  for (const v of vals) if (v && String(v).trim()) return String(v).trim();
  return '';
}

function nextStudentCode() {
  const year = new Date().getFullYear();
  const prefix = `STU-${year}-`;
  const last = get('SELECT student_code FROM students WHERE student_code LIKE ? ORDER BY id DESC LIMIT 1', [prefix + '%']);
  let n = 1;
  if (last) {
    const m = /\d+$/.exec(last.student_code);
    if (m) n = parseInt(m[0], 10) + 1;
  }
  return prefix + String(n).padStart(4, '0');
}

// ---------------------------------------------------------------------------
// Step 5 — import (transactional)
// ---------------------------------------------------------------------------
router.post('/import', authenticate, requireStaffAdmin, (req, res) => {
  const sess = session(cleanString(req.body.importId, 40));
  if (!sess) return res.status(404).json({ error: 'Import session expired. Upload the file again.' });
  const mapping = req.body.mapping || {};
  const academicYear = cleanString(req.body.academicYear, 20) || '2026';

  const results = sess.rows.map((row, index) => validateRow(row, mapping, academicYear, index, sess));
  const validRows = results.filter((r) => r.status !== 'error');

  const school = require('../services/settingsService').readSettings().school;
  const defaultPassword = school.defaultStudentPassword || 'Student@123';

  // username helper: make a unique, username-safe login code from a base string
  function makeUsername(base) {
    const clean = String(base || '').replace(/[^a-zA-Z0-9_.]/g, '').slice(0, 24);
    const root = clean || 'student';
    let candidate = root;
    let n = 1;
    while (get('SELECT id FROM users WHERE username = ?', [candidate])) {
      candidate = root.slice(0, 24 - String(n).length - 1) + '_' + n;
      n++;
    }
    return candidate;
  }

  let imported = 0;
  const failures = [];
  const credentials = []; // {name, username, password}

  try {
    tx(() => {
      for (const r of validRows) {
        const d = r.data;
        try {
          const studentCode = d.studentCode || nextStudentCode();
          // username = provided value OR a code derived from the student ID
          let username = d.username;
          if (!username) username = makeUsername(d.studentCode || ('stu_' + studentCode));
          const password = d.password || defaultPassword;

          if (!get('SELECT id FROM users WHERE username = ?', [username])) {
            const info = run(
              `INSERT INTO users (full_name, email, phone, username, password_hash, role, status, registration_status, email_verified, must_change_password)
               VALUES (?, ?, ?, ?, ?, 'student', 'active', 'approved', 1, 1)`,
              [d.fullName, d.parentEmail || null, d.parentPhone || null, username, bcrypt.hashSync(password, 10)]
            );
            const userId = info.lastInsertRowid;
            run(
              `INSERT INTO students (user_id, student_code, full_name, class_id, stream, gender, date_of_birth,
                                     parent_name, parent_phone, parent_email, address, enrollment_date, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
              [userId, studentCode, d.fullName, d.classId || null, d.stream || null, d.gender || null, d.dateOfBirth || null,
               d.parentName || null, d.parentPhone || null, d.parentEmail || null, d.address || null, d.enrollmentDate || null]
            );
            credentials.push({ name: d.fullName, username, password });
            imported++;

            // Guardian columns become a real parent account linked to the child,
            // so fees, reports and messages reach them from any import path.
            if (d.parentName || d.parentPhone || d.parentEmail) {
              try {
                const hub = require('../services/importHub');
                const studentRow = get('SELECT * FROM students WHERE student_code = ?', [studentCode]);
                const guardian = hub.resolveParent({
                  name: d.parentName || `Parent of ${d.fullName}`,
                  phone: d.parentPhone,
                  email: d.parentEmail,
                  password: school.defaultParentPassword || 'Parent@123',
                  bcrypt,
                });
                if (guardian && guardian.id && studentRow) {
                  hub.linkParentStudent(guardian.id, studentRow.id, d.relationship || '');
                  if (guardian.created && guardian.credentials) credentials.push(guardian.credentials);
                }
              } catch (e) {
                // never fail a student import over the guardian: say so instead
                failures.push({ row: r.index + 2, name: d.fullName, reason: `Student saved, guardian not linked: ${e.message}` });
              }
            }
          } else {
            failures.push({ row: r.index + 2, name: d.fullName, reason: `Username "${username}" already exists` });
          }
        } catch (e) {
          failures.push({ row: r.index + 2, name: d.fullName, reason: e.message });
        }
      }
    });
  } catch (e) {
    run('UPDATE imports SET status = \'failed\' WHERE id = ?', [sess.importDbId || 0]);
    log(req.user, 'IMPORT_FAILED', `Import "${sess.filename}" failed: ${e.message}`, req.ip);
    return res.status(500).json({ error: 'The import failed and was rolled back. No partial data was saved.' });
  }

  const counts = { imported, failed: failures.length, skipped: results.filter((r) => r.status === 'error').length + failures.length, warnings: results.filter((r) => r.status === 'warning').length };
  const payload = { status: 'imported', counts: JSON.stringify(counts), credentials: JSON.stringify(credentials) };
  run('UPDATE imports SET status = ?, counts = ?, credentials = ? WHERE id = ?', [payload.status, payload.counts, payload.credentials, sess.importDbId || 0]);
  log(req.user, 'STUDENT_IMPORTED', `Imported ${imported} students from "${sess.filename}" (${counts.skipped} skipped)`, req.ip);

  res.json({
    message: `Import complete: ${imported} student${imported === 1 ? '' : 's'} imported. Each student was given a login code (username) and a default password — they will be asked to change it on first login.`,
    counts,
    failures: failures.slice(0, 100),
    credentials: credentials.slice(0, 200),
    credentialsCount: credentials.length,
  });
});

// ---------------------------------------------------------------------------
// Step 7 — report download + history + template
// ---------------------------------------------------------------------------

/** GET /api/imports/:id/report.csv — download an error report for an import. */
router.get('/:id/report.csv', authenticate, requireStaffAdmin, (req, res) => {
  const imp = get('SELECT * FROM imports WHERE id = ?', [asInt(req.params.id)]);
  if (!imp) return res.status(404).json({ error: 'Import record not found.' });
  let counts = {};
  try { counts = JSON.parse(imp.counts || '{}'); } catch {}
  let csv = 'Import report for "' + imp.filename + '"\n';
  csv += `Imported,${counts.imported || 0}\nSkipped,${counts.skipped || 0}\nFailed,${counts.failed || 0}\nWarnings,${counts.warnings || 0}\n`;
  csv += '\nNote: per-row failure details are returned to the browser in the import dialog.\n';
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="import-report-${imp.id}.csv"`);
  res.send(csv);
});

/** GET /api/imports — import history. */
router.get('/', authenticate, requireStaffAdmin, (req, res) => {
  const imports = all(
    `SELECT i.*, u.full_name AS created_by_name FROM imports i
     LEFT JOIN users u ON u.id = i.created_by ORDER BY i.id DESC LIMIT 100`
  );
  for (const i of imports) { try { i.counts = JSON.parse(i.counts || '{}'); } catch { i.counts = {}; } }
  res.json({ imports });
});

/**
 * GET /api/imports/template.csv?type=students|teachers|fees
 * Downloadable starter templates showing EXACTLY how to organise the data.
 * Codes/usernames/passwords may be left blank — the system generates them.
 */
router.get('/template.csv', authenticate, requireStaffAdmin, (req, res) => {
  const type = cleanString(req.query.type, 20) || 'students';
  let filename, content;
  if (type === 'teachers') {
    filename = 'teacher-import-template.csv';
    content =
      'Full Name,Staff ID,Email,Phone,Subjects,Qualification,Date Joined\n' +
      'Ms. Grace Atim,TCH-2026-01,grace@example.com,+256700000040,"Mathematics, Physics",BSc Education,2024-02-01\n' +
      'Mr. Peter Okoth,,peter@example.com,+256700000041,English,BA Arts with Education,\n' +
      '"# Staff ID is optional - leave blank and the system generates one (e.g. TCH-2026-07).",,,,,,\n' +
      '"# Each teacher automatically gets a login account: username = staff ID, default password, forced change on first login.",,,,,,\n';
  } else if (type === 'fees') {
    filename = 'fees-import-template.csv';
    content =
      'Fee Name,Amount,Year,Term,Class\n' +
      'Term 1 Tuition,850000,2026,Term 1,Senior 1 A\n' +
      'Term 1 Tuition,900000,2026,Term 1,Senior 2 A\n' +
      'Development Fee,150000,2026,Term 1,\n' +
      '"# Leave Class blank to apply the fee to ALL classes.",,,,\n' +
      '"# Amount is in UGX with no commas. Each row becomes a fee structure automatically assigned to its class students.",,,,\n';
  } else {
    filename = 'student-import-template.csv';
    content =
      'Full Name,Student ID,Class,Stream,Gender,Date of Birth,Parent Name,Parent Phone,Parent Email,Address,Enrollment Date,Username,Password\n' +
      'Sarah Namuli,STU-2026-100,Senior 2,A,Female,2010-04-12,John Namuli,+256700000030,john@example.com,Kampala,,sarah2026,Student@123\n' +
      'Brian Mukasa,,Senior 2,A,Male,2009-07-19,Peter Mukasa,+256700000031,,Entebbe,2026-02-01,,\n' +
      '"# Student ID / Username / Password are optional - leave blank and the system generates them automatically.",,,,,,,,,,,,\n' +
      '"# Students log in with their username OR student code + password (changed on first login).",,,,,,,,,,,,\n';
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(content);
});

// ---------------------------------------------------------------------------
// One-step TEACHER import: upload -> validate -> create accounts + codes
// ---------------------------------------------------------------------------
async function parseSpreadsheet(file) {
  const ext = (file.originalname.split('.').pop() || '').toLowerCase();
  if (!IMPORT_TYPES.includes(ext)) throw Object.assign(new Error(unsupportedMessage(ext)), { status: 400 });
  const rows = await readRows(file.path, ext);
  return rows
    .map((r) => {
      const o = {};
      for (const k of Object.keys(r)) {
        const key = String(k).trim().toLowerCase();
        // prototype-polluting header keys can never become properties
        if (DANGEROUS_KEYS.has(key)) continue;
        o[key] = typeof r[k] === 'number' ? r[k] : String(r[k]).trim();
      }
      return o;
    })
    // skip helper/comment rows from the template
    .filter((r) => !String(Object.values(r)[0] || '').startsWith('#'));
}
function pick(row, ...names) {
  for (const n of names) {
    if (row[n] !== undefined && row[n] !== '') return row[n];
  }
  return '';
}

function nextTeacherCode() {
  const year = new Date().getFullYear();
  for (let i = 1; i < 10000; i++) {
    const code = `TCH-${year}-${String(i).padStart(2, '0')}`;
    if (!get('SELECT id FROM teachers WHERE staff_code = ?', [code])) return code;
  }
  return 'TCH-' + Date.now().toString(36).toUpperCase();
}

router.post('/teachers', authenticate, requireStaffAdmin, upload.single('file'), handleUploadErrors, async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a file to upload.' });
  let rows;
  try { rows = await parseSpreadsheet(req.file); }
  catch (e) { try { fs.unlinkSync(req.file.path); } catch {} return res.status(e.status || 400).json({ error: e.message }); }
  try { fs.unlinkSync(req.file.path); } catch {}
  if (!rows.length) return res.status(400).json({ error: 'The file contains no data rows.' });
  if (rows.length > 1000) return res.status(400).json({ error: `Too many rows (${rows.length}). Maximum is 1000.` });

  const school = require('../services/settingsService').readSettings().school;
  const defaultPassword = school.defaultTeacherPassword || 'Teacher@123';
  const academicYear = String(new Date().getFullYear());
  let imported = 0;
  const failures = [];
  const credentials = [];

  tx(() => {
    rows.forEach((row, i) => {
      const fullName = cleanString(pick(row, 'full name', 'name', 'teacher'), 120);
      if (!fullName) { failures.push({ row: i + 2, name: '(blank)', reason: 'Full name is required' }); return; }
      const email = cleanString(pick(row, 'email', 'email address'), 160).toLowerCase();
      if (email && !isEmail(email)) { failures.push({ row: i + 2, name: fullName, reason: `Invalid email "${email}"` }); return; }
      if (email && get('SELECT id FROM users WHERE lower(email) = lower(?)', [email])) {
        failures.push({ row: i + 2, name: fullName, reason: `Email "${email}" already registered` }); return;
      }
      let staffCode = cleanString(pick(row, 'staff id', 'staff code', 'staff no', 'code'), 30).toUpperCase();
      if (staffCode && get('SELECT id FROM teachers WHERE upper(staff_code) = ?', [staffCode])) {
        failures.push({ row: i + 2, name: fullName, reason: `Staff ID "${staffCode}" already exists` }); return;
      }
      if (!staffCode) staffCode = nextTeacherCode();
      // username = staff code, lowercased & cleaned (login also works with the code itself)
      let username = staffCode.toLowerCase().replace(/[^a-z0-9_.-]/g, '');
      let n = 1;
      while (get('SELECT id FROM users WHERE username = ?', [username])) username = staffCode.toLowerCase().replace(/[^a-z0-9_.-]/g, '') + '_' + n++;

      const info = run(
        `INSERT INTO users (full_name, email, phone, username, password_hash, role, status, registration_status, email_verified, must_change_password)
         VALUES (?, ?, ?, ?, ?, 'teacher', 'active', 'approved', 1, 1)`,
        [fullName, email || null, cleanString(pick(row, 'phone', 'phone number'), 30) || null, username, bcrypt.hashSync(defaultPassword, 10)]
      );
      run(
        `INSERT INTO teachers (user_id, staff_code, full_name, subjects, phone, email, qualification, date_joined, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
        [info.lastInsertRowid, staffCode, fullName,
          cleanString(pick(row, 'subjects', 'subject'), 300) || null,
          cleanString(pick(row, 'phone', 'phone number'), 30) || null,
          email || null,
          cleanString(pick(row, 'qualification'), 200) || null,
          normalizeDate(pick(row, 'date joined', 'joined')).value || null]
      );
      credentials.push({ name: fullName, username, staffCode, password: defaultPassword });
      imported++;

      // Link the teacher the way the platform reads it (class + subjects), so a
      // teacher imported through this older screen behaves like an imported one.
      try {
        const hub = require('../services/importHub');
        const teacherRow = get('SELECT * FROM teachers WHERE staff_code = ?', [staffCode]);
        const subjectList = hub.splitList(pick(row, 'subjects', 'subject', 'teaching subjects'));
        const classList = hub.splitList(pick(row, 'classes', 'class', 'class teacher of'));
        for (const subj of subjectList) hub.resolveSubject(subj, { create: true });
        for (const label of classList) {
          const { name: cn, stream } = hub.splitClassLabel(label);
          const cls = hub.resolveClass(cn, stream, academicYear, { create: true });
          if (!cls.id) continue;
          const rel = pick(row, 'role', 'position');
          const asClassTeacher = /class\s*teacher|form master|form mistress/i.test(String(rel || ''));
          for (const subj of (subjectList.length ? subjectList : [''])) {
            hub.linkTeacherClass(teacherRow.id, cls.id, subj, { asClassTeacher: asClassTeacher && subj === (subjectList[0] || '') });
          }
        }
      } catch (e) {
        failures.push({ row: i + 2, name: fullName, reason: `Teacher saved, class links skipped: ${e.message}` });
      }
    });
  });

  const info2 = run('INSERT INTO imports (filename, kind, status, counts, credentials, created_by) VALUES (?, \'teachers\', \'imported\', ?, ?, ?)',
    [req.file.originalname, JSON.stringify({ imported, failed: failures.length }), JSON.stringify(credentials), req.user.id]);
  log(req.user, 'TEACHER_IMPORTED', `Imported ${imported} teachers from "${req.file.originalname}" (${failures.length} failed)`, req.ip);
  res.json({
    message: `Import complete: ${imported} teacher${imported === 1 ? '' : 's'} imported. Each was given a staff code + login (username = staff code, default password, changed on first login).`,
    importId: info2.lastInsertRowid,
    counts: { imported, failed: failures.length },
    failures: failures.slice(0, 100),
    credentials: credentials.slice(0, 200),
  });
});

// ---------------------------------------------------------------------------
// One-step FEES import: each row -> fee structure (+ auto-assign to class)
// ---------------------------------------------------------------------------
router.post('/fees', authenticate, requireStaffAdmin, upload.single('file'), handleUploadErrors, async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a file to upload.' });
  let rows;
  try { rows = await parseSpreadsheet(req.file); }
  catch (e) { try { fs.unlinkSync(req.file.path); } catch {} return res.status(e.status || 400).json({ error: e.message }); }
  try { fs.unlinkSync(req.file.path); } catch {}
  if (!rows.length) return res.status(400).json({ error: 'The file contains no data rows.' });
  if (rows.length > 500) return res.status(400).json({ error: `Too many rows (${rows.length}). Maximum is 500.` });

  let imported = 0, assigned = 0;
  const failures = [];

  tx(() => {
    rows.forEach((row, i) => {
      const name = cleanString(pick(row, 'fee name', 'name', 'fee'), 150);
      const amount = parseFloat(String(pick(row, 'amount', 'amount (ugx)')).replace(/[^\d.]/g, ''));
      if (!name || !amount || amount <= 0) { failures.push({ row: i + 2, name: name || '(blank)', reason: 'Fee name and a positive amount are required' }); return; }
      const year = cleanString(String(pick(row, 'year', 'academic year')), 10) || String(new Date().getFullYear());
      const term = cleanString(pick(row, 'term'), 30) || null;
      const className = cleanString(pick(row, 'class', 'class name'), 60);
      let classId = null;
      if (className) {
        classId = classForName(className, cleanString(pick(row, 'stream'), 10), year) ||
                  classForName(className, cleanString(pick(row, 'stream'), 10), '2026');
        if (!classId) { failures.push({ row: i + 2, name, reason: `Class "${className}" not found` }); return; }
      }
      const info = run(
        'INSERT INTO fee_structures (name, amount, academic_year, term, class_id) VALUES (?, ?, ?, ?, ?)',
        [name, amount, year, term, classId]
      );
      imported++;
      // auto-assign to the class's active students (or ALL active students when no class)
      const students = classId
        ? all("SELECT id FROM students WHERE class_id = ? AND status = 'active'", [classId])
        : all("SELECT id FROM students WHERE status = 'active'");
      for (const s of students) {
        run('INSERT OR IGNORE INTO student_fees (student_id, fee_structure_id, amount) VALUES (?, ?, ?)', [s.id, info.lastInsertRowid, amount]);
        assigned++;
      }
    });
  });

  run('INSERT INTO imports (filename, kind, status, counts, created_by) VALUES (?, \'fees\', \'imported\', ?, ?)',
    [req.file.originalname, JSON.stringify({ imported, failed: failures.length, assigned }), req.user.id]);
  log(req.user, 'FEES_IMPORTED', `Imported ${imported} fee structures from "${req.file.originalname}" (${assigned} student assignments)`, req.ip);
  res.json({
    message: `Import complete: ${imported} fee structure${imported === 1 ? '' : 's'} created and assigned to ${assigned} student record${assigned === 1 ? '' : 's'}.`,
    counts: { imported, failed: failures.length, assigned },
    failures: failures.slice(0, 100),
  });
});

module.exports = router;

/** GET /api/imports/:id/credentials.csv — download login codes for an import. */
router.get('/:id/credentials.csv', authenticate, requireStaffAdmin, (req, res) => {
  const imp = get('SELECT * FROM imports WHERE id = ?', [asInt(req.params.id)]);
  if (!imp) return res.status(404).json({ error: 'Import record not found.' });
  let creds = [];
  try { creds = JSON.parse(imp.credentials || '[]'); } catch { creds = []; }
  if (!creds.length) return res.status(404).json({ error: 'No credentials stored for this import.' });
  let csv = 'Name,Username (login code),Default Password\n';
  for (const c of creds) {
    csv += `"${String(c.name).replace(/"/g, '""')}",${c.username},${c.password}\n`;
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="import-credentials-${imp.id}.csv"`);
  res.send(csv);
});
